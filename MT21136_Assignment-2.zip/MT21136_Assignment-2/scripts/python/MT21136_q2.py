#!/usr/bin/env python
# coding: utf-8

# In[3]:


# Importing Libraries
import os
import shutil
import cv2
import numpy as np
from fcmeans import FCM


# In[4]:


# Using LBP for feature extraction
def calculate_lbp(image, center_x, center_y):
    current_pixel = image[center_x][center_y]
    change_x = [-1, -1, -1, 0, 1, 1, 1, 0]
    change_y = [-1, 0, 1, 1, 1, 0, -1, -1]
    powers = [1, 2, 4, 8, 16, 32, 64, 128]
    thresholds = []
    length = 8
    for i in range(length):
        try:
            neighbour_pixel = image[center_x + change_x[i]][center_y + change_y[i]]
            val = round(min(current_pixel, neighbour_pixel) / max(current_pixel, neighbour_pixel))
            thresholds.append(val * powers[i])
        except IndexError as e:
            thresholds.append(0)
        except ValueError as e:
            thresholds.append(0)
            # print(current_pixel, neighbour_pixel)
    return sum(thresholds)


# In[5]:


# Using histogram for each image
def calculate_histogram(image):
    rows, columns = np.shape(image)
    lbp_values = []
    for i in range(rows):
        for j in range(columns):
            lbp_values.append(calculate_lbp(image, i, j))
    hist, _ = np.histogram(lbp_values, bins=256)
    return hist


# In[6]:


def calculate_patch(start,end,patch_size):
    patches = []
    while start < end:
        patch = (start, start+patch_size)
        patches.append(patch)
        start = start+patch_size
    return patches


# In[7]:



images = []
features = []
column_names = ["feature_{}".format(i) for i in range(1,5377)]
count = 1
for file in os.listdir('D:/IIITD/ComputerVision/assignments/assignment2/CV_A2_Q3/dd/'):
    print("Processing Image..{}, count = {}".format(file, count))
    count = count + 1
    feature = []
    img = cv2.imread('D:/IIITD/ComputerVision/assignments/assignment2/CV_A2_Q3/dd/{}'.format(file))
    img = cv2.resize(img, (224, 224))
    img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    images.append(file)
    patch_sizes = [224, 112, 56]
    for size in patch_sizes:
        patch = calculate_patch(0, 224, size)
        for start in patch:
            for end in patch:
                histogram = calculate_histogram(img[start[0]:start[1], end[0]:end[1]])
                feature.extend(histogram.flatten())
    features.append(feature)

data = np.array(features)
print(np.shape(data))

# Input cluster and then save images on each clusterof particular cat and dog
clusters = int(input('Enter no of Clusters :'))
# Using Library fuzzy means cluster
model = FCM(n_clusters=clusters)
model.fit(data)

centers = model.centers
labels = model.predict(data)

print(centers)
print(labels)

# Assigning path to save images
if os.path.exists('D:/IIITD/ComputerVision/assignments/assignment2/CV_A2_Q3/dd/Output_3'):
    shutil.rmtree('D:/IIITD/ComputerVision/assignments/assignment2/CV_A2_Q3/dd/Output_3')

os.mkdir('D:/IIITD/ComputerVision/assignments/assignment2/CV_A2_Q3/dd/Output')

unique_labels = np.unique(labels)
for label in unique_labels:
    os.mkdir('D:/IIITD/ComputerVision/assignments/assignment2/CV_A2_Q3/dd/Output/Cluster_{}'.format(label+1))

for index in range(len(labels)):
    label = labels[index]
    file = images[index]
    src = 'D:/IIITD/ComputerVision/assignments/assignment2/CV_A2_Q3/dd/{}'.format(file)
    dest = 'D:/IIITD/ComputerVision/assignments/assignment2/CV_A2_Q3/dd/Output/Cluster_{}'.format(label+1)
    shutil.copy(src, dest)


# In[ ]:





# In[ ]:




