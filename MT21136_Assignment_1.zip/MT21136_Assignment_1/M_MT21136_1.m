%% Applying Kmeans Clustering K= 85
clc
clear all
close all
warning off
rgbImage=imread('C:/Users/Prajwal Phulauriya/Desktop/leaf.png');
subplot(1,2,1);
imshow(rgbImage);
redChannel=rgbImage(:, :, 1);
greenChannel=rgbImage(:, :, 2);
blueChannel=rgbImage(:, :, 3);
data=double([redChannel(:), greenChannel(:), blueChannel(:)]);
numberOfClasses= 85;
[m n]=kmeans(data,numberOfClasses);
m=reshape(m,size(rgbImage,1),size(rgbImage,2));
n=n/255;
clusteredImage=label2rgb(m,n);
subplot(1,2,2);
imshow(clusteredImage);


% Implementing Equation 3 on leaf Image
I= clusteredImage;
[bincount,binloc]=hist(double(I(:,:,3)),256);
% plot(binloc,bincount)
m=sum(bincount.*binloc)/sum(bincount);
Ig=rgb2gray(I);
msk=I(:,:,3)<=m-10;
msk=bwareaopen(msk,250);
msk3=cat(3,msk,msk,msk);
Icrop=immultiply(I,msk3);
%imshowpair(I,Icrop,'montage')
BW4 = im2bw(Icrop);
BW5 = imfill(BW4,'holes');
figure, imshow(BW5)
imwrite(BW5,'C:/Users/Prajwal Phulauriya/Desktop/Equation3.png')

%% Implementing Equation 5
%%clc
clear all
close all
warning off
RGB=imread('C:/Users/Prajwal Phulauriya/Desktop/BigTree.jpg');
subplot(1,3,1);
imshow(RGB);
title('Orignal Image');

% Implementing Segmentation on Tree Image
[BW,maskedImage] = segmentImage(RGB)

subplot(1,3,2);
imshow(BW);
title('Segmented Binary Image');

subplot(1,3,3);
imshow(maskedImage);
title('Segmented Color Image');
%imwrite(maskedImage,'C:/Users/Prajwal Phulauriya/Desktop/Equation1.png');

% convert it to gray image using rgb2gray() function. 
Ig = rgb2gray(maskedImage);   
     
T = graythresh(Ig);        
Tg = T*255; 
 
% detect foreground and background
% pixels of the binary image.              
m = Ig > Tg                  
figure, imshow(m); 
        
I1 = I(:, :, 1);             
I2 = I(:, :, 2);
I3 = I(:, :, 3);
I1(~m) = 0;
I2(~m) = 0;


I3(~m) = 255;                
In=cat(3, I1, I2, I3);
figure, imshow(In);

imwrite(In,'C:/Users/Prajwal Phulauriya/Desktop/Equation5.png');


