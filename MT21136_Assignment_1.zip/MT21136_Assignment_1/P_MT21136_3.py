# Importing Libraries
import cv2
import numpy as np

# Capturing Vedio
cap = cv2.VideoCapture('C:/Users/Prajwal Phulauriya/Desktop/shahar_walk.avi')

operations = cv2.VideoWriter_fourcc('X', 'V', 'I', 'D')

out = cv2.VideoWriter("output.avi", operations, 5.0, (1280, 720))

# Reading 1st Frame
ret, frame1 = cap.read()
# ret, frame2 = cap.read()

# Here I have used this in order to calculate the median of the all frame present in the vedio
FOI = cap.get(cv2.CAP_PROP_FRAME_COUNT) * np.random.uniform(size=30)

frames = []
for frameOI in FOI:
    cap.set(cv2.CAP_PROP_POS_FRAMES, frameOI)
    ret, frame = cap.read()
    frames.append(frame)

# Computing Mean
result2 = np.median(frames, axis=0).astype(dtype=np.uint8)

while cap.isOpened():
    diff = cv2.absdiff(result2, frame1)
    gray = cv2.cvtColor(diff, cv2.COLOR_BGR2GRAY)
    blur = cv2.GaussianBlur(gray, (5, 5), 0)
    _, thresh = cv2.threshold(blur, 20, 255, cv2.THRESH_BINARY)
    dilated = cv2.dilate(thresh, None, iterations=3)
    contours, _ = cv2.findContours(dilated, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)

    # Here I used circular bounding figure
    for contour in contours:
        # (x, y, w, h) = cv2.boundingRect(contour)
        center, radius = cv2.minEnclosingCircle(contour)
        if cv2.contourArea(contour) < 900:
            continue
        # cv2.rectangle(frame1, (x, y), (x+w, y+h), (0, 255, 0), 2)
        # Implementing Circular Contour
        cv2.circle(frame1, (int(center[0]), int(center[1])), int(radius), (0, 0, 255), 10)
    # cv2.drawContours(frame1, contours, -1, (0, 255, 0), 2)

    image = cv2.resize(frame1, (1280, 720))
    out.write(image)
    cv2.imshow("feed", frame1)
    ret, frame1 = cap.read()

    if cv2.waitKey(400) & 0xFF == ord('q'):  # press q to exit and I have increased time here so that vedio could be seen longer
        break
cv2.destroyAllWindows()
cap.release()
out.release()
