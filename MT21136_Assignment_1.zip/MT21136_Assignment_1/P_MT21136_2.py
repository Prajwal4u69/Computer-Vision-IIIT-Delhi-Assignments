    # Importing Libraries
    import pandas as pd 
    import numpy as np
    from PIL import Image, ImageOps
    import matplotlib.pyplot as plt 
    #rom PIL import Image 
    #mport PIL 

    image = np.array(Image.open('C:/Users/Prajwal Phulauriya/Desktop/horse.jpg').convert('L'))
        

    
    his, bins = np.histogram(image, np.array(range(0, 256)))
    final_thresh = -1
    final_value = -1
    
    
    
    thres_list = bins 
    for x in bins[1:-1]:
        Wb = np.sum(his[:x])
        Wf = np.sum(his[x:]) 
        
        #Clculating Mean
        mub = np.mean(his[:x])
        muf = np.mean(his[x:])

        #Calculating TSS
        value = (mub - muf) ** 2

        
        if value > final_value:
            final_thresh = x
            final_value = value
        thres_list[x] =  final_thresh
        
    final_img = image.copy()
    
    
    print(final_thresh)
    print("ThreshHold Values",thres_list)
    final_img[image > final_thresh] = 255
    final_img[image < final_thresh] = 0
    
    plt.imshow(final_img,cmap='gray')
    
    df = pd.DataFrame(thres_list)
  
    # saving the threshold values
    df.to_csv('C:/Users/Prajwal Phulauriya/Desktop/Thresh.csv')
    
    # saving the Final Image
    plt.savefig("C:/Users/Prajwal Phulauriya/Desktop/Output_2.png")

    
    plt.show()
