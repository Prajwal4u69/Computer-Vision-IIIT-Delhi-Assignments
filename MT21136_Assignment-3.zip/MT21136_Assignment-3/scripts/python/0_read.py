import sys
from PIL import Image

# Open and read img
imageName = sys.argv[1]
im = Image.open(imageName)
im = im.resize((128, 128))
pix = im.load()
xVal, yVal = im.size
pointsArray = []

# Map pixel values to array
for y in range(yVal):
    pointsArray.append([])
    for x in range(xVal):
        pointsArray[y].append(list(pix[x, y]))

print(pointsArray)

# Log
with open('D:/IIITD/ComputerVision/assignments/assignment3/A3_Q2/log.txt', 'a+') as out:
    out.write(f"""**READING IMAGE {imageName}**\n""")

# Command to run in terminal
# python 0_read.py 0002.jpg | python 0_dbscan.py 100 100 2 | python 0_save.py 0002_100_100_e.jpg
# python 0_read.py 0002.jpg | python 0_kmeans.py 5 | python 0_save.py 0002_100_100_e.jpg