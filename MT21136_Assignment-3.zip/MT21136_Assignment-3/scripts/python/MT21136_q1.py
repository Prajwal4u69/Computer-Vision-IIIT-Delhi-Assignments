#!/usr/bin/env python
# coding: utf-8

# In[15]:


# import the necessary packages
from skimage.segmentation import slic
from skimage.segmentation import mark_boundaries
from skimage.util import img_as_float
from skimage import io
import matplotlib.pyplot as plt
import numpy as np
import math
def pixels(segment_count):
    image_path = 'D:/IIITD/ComputerVision/assignments/assignment3/A3_Q2/002.jpg'
    image = img_as_float(io.imread(image_path))

    segments = slic(image, n_segments = 10000, sigma = 5)
    #sigma , is a smoothing Gaussian kernel 
    #To draw the actual superpixel segmentations, we have mark_boundaries function which groups the regions that are same
    plt.imshow(mark_boundaries(image, segments))

    #store the values of the image that we received after applying slic and reshape 
    r, c = np.shape(segments)
    new_array = np.reshape(segments, r*c)
    labels = np.unique(new_array)
    length = len(labels)
        
    sp_R = [0]*length
    sp_G = [0]*length
    sp_B = [0]*length
    sp_X = [0]*length
    sp_Y = [0]*length
    iR, iG, iB = image[:,:,0], image[:,:,1], image[:,:,2]

    iR = np.reshape(iR, r*c)
    iG = np.reshape(iG, r*c)
    iB = np.reshape(iB, r*c)
    
    # make arrays to store unique superpixel RGB values.
    for label in labels:
        iR[np.where(new_array == label)] = np.mean(iR[np.where(new_array == label)])
        iG[np.where(new_array == label)] = np.mean(iG[np.where(new_array == label)])
        iB[np.where(new_array == label)] = np.mean(iB[np.where(new_array == label)])
        
        # These arrays contain the unique super-pixel color values
        sp_R[label] = np.mean(iR[np.where(new_array == label)])
        sp_G[label] = np.mean(iG[np.where(new_array == label)])
        sp_B[label] = np.mean(iB[np.where(new_array == label)])
        
        sp_X[label] = np.mean(np.where(segments == label)[0])
        sp_Y[label] = np.mean(np.where(segments == label)[1])

    #get the segmented image and reshape 
    segmented_image = np.zeros(np.shape(image))
    segmented_image[:,:,0] = np.reshape(iR, (r,c))
    segmented_image[:,:,1] = np.reshape(iG, (r,c))
    segmented_image[:,:,2] = np.reshape(iB, (r,c))
    
    print(type(segmented_image[0,0,0]))
    print(np.min(segmented_image))
    print(np.max(segmented_image))
    plt.imshow(segmented_image)
    return segmented_image, new_array, sp_R, sp_G, sp_B, sp_X, sp_Y
    
#call the function
segmented_image, new_array, sp_R, sp_G, sp_B, sp_X, sp_Y = pixels(5000)


# In[16]:


#define length for R's superpixel
length = len(sp_R)
saliency_values = [0]*length

#store height and width values of segmented image

height, width, _ = np.shape(segmented_image)
#apply the formula as given.
height2_width2 = np.sqrt(width*width + height*height)

#loop through the length and compute the distances for RGB and compute saliency values
for i in range(length):
    temp_saliency = 0
    for j in range(length):
        color_distance = np.sqrt(((sp_R[i]-sp_R[j])**2) + ((sp_G[i]-sp_G[j])**2) + ((sp_B[i]-sp_B[j])**2))
        spatial_distance = np.sqrt(((sp_X[i]-sp_X[j])**2) + ((sp_Y[i]-sp_Y[j])**2))
        val = color_distance * math.exp(-(spatial_distance/height2_width2))
        temp_saliency = temp_saliency + val
    saliency_values[i] = temp_saliency



#perform below task for getting the saliency map for segmented image    
r, c, _ = np.shape(segmented_image)
labels = np.unique(new_array)

iR, iG, iB = segmented_image[:,:,0], segmented_image[:,:,1], segmented_image[:,:,2]

iR = np.reshape(iR, r*c)
iG = np.reshape(iG, r*c)
iB = np.reshape(iB, r*c)

for label in labels:
    iR[np.where(new_array == label)] = saliency_values[label]
    iG[np.where(new_array == label)] = saliency_values[label]
    iB[np.where(new_array == label)] = saliency_values[label]   

iR *= (1.0/iR.max())
iG *= (1.0/iG.max())
iB *= (1.0/iB.max())
    
result_image = np.zeros(np.shape(segmented_image))

result_image[:,:,0] = np.reshape(iR, (r,c))
result_image[:,:,1] = np.reshape(iG, (r,c))
result_image[:,:,2] = np.reshape(iB, (r,c))


io.imshow(result_image)


# In[ ]:




